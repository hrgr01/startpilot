Välkommen till Startpilot – Din AI-drivna startupmotor.

Filer:
- frontend/: Next.js + Tailwind
- backend/: GPT-4 AI-flöde
- docs/: lanseringsplan, investerar-PDF
- email/: färdiga flöden
- media/: video placeholders

Kör README först för att komma igång.
Support: hrgr01@icloud.com